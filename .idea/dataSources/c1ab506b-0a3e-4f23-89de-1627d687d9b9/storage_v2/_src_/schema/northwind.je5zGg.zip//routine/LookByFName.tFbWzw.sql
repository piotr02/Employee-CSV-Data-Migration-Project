create
    definer = root@localhost procedure LookByFName(IN AtFirstLetter char)
BEGIN
     SELECT * FROM Employees  Where LEFT(FirstName, 1)=AtFirstLetter;

END;

