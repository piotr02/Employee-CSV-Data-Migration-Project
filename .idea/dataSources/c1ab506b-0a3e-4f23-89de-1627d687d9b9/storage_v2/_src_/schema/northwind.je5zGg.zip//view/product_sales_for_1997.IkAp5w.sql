create definer = root@localhost view `product sales for 1997` as
select `northwind`.`categories`.`CategoryName`                             AS `CategoryName`,
       `northwind`.`products`.`ProductName`                                AS `ProductName`,
       sum(((((`northwind`.`order details`.`UnitPrice` * `northwind`.`order details`.`Quantity`) *
              (1 - `northwind`.`order details`.`Discount`)) / 100) * 100)) AS `ProductSales`
from (((`northwind`.`categories` join `northwind`.`products` on ((`northwind`.`categories`.`CategoryID` =
                                                                  `northwind`.`products`.`CategoryID`))) join `northwind`.`order details` on ((
        `northwind`.`products`.`ProductID` = `northwind`.`order details`.`ProductID`)))
         join `northwind`.`orders` on ((`northwind`.`orders`.`OrderID` = `northwind`.`order details`.`OrderID`)))
where (`northwind`.`orders`.`ShippedDate` between '1997-01-01' and '1997-12-31')
group by `northwind`.`categories`.`CategoryName`, `northwind`.`products`.`ProductName`;

