create definer = root@localhost view retirement as
select concat(`northwind`.`employees`.`FirstName`, ' ', `northwind`.`employees`.`LastName`) AS `Employee Name`,
       floor(((to_days(now()) - to_days(`northwind`.`employees`.`BirthDate`)) / 365.25))    AS `Age`,
       (case
            when (floor(((to_days(now()) - to_days(`northwind`.`employees`.`BirthDate`)) / 365.25)) >= 65)
                then 'Retired'
            when (floor(((to_days(now()) - to_days(`northwind`.`employees`.`BirthDate`)) / 365.25)) >= 60)
                then 'Retirement Due'
            else 'More than 5 years to go' end)                                             AS `Retirement`
from `northwind`.`employees`;

