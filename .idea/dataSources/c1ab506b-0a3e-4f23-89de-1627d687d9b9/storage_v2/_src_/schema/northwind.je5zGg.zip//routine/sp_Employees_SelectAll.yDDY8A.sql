create
    definer = root@localhost procedure sp_Employees_SelectAll()
BEGIN
SELECT * FROM Employees;

END;

